const t0 = performance.now();

const ctg_ptr = {
  1: [
    {
      S: [
        ["vrb_better", "pro_your", "noun_situation"],
        ["vrb_better", "pro_your", "noun_situation", "adPhr_1"],
      ],
    },

    { Your: [["noun_situation", "vrb_better", "adPhr"]] },
  ],
  2: [
    {
      S: [
        ["vrb_bless", "pro_your", "noun_business"],
        ["vrb_bless", "pro_your", "noun_business", "adv_abundantly"],
      ],
    },
    {
      S: [
        [
          "vrb_bestow",
          "pro_with",
          "adj_great",
          "noun_success",
          "prep_inyour",
          "noun_business",
        ],
      ],
    },
    {
      S: [
        ["vrb_make", "pro_your", "noun_business", "adv_very", "adj_successful"],
        [
          "vrb_make",
          "pro_your",
          "noun_business",
          "adv_very",
          "adj_successful",
          "adPhr_1",
        ],
      ],
    },
    {
      You: [
        ["kw_be", "adv_very", "adj_successful", "prep_inyour", "noun_business"],
      ],
    },
  ],
  3: [
    {
      S: [
        ["vrb_bless", "pro_your", "noun_career"],
        ["vrb_bless", "pro_your", "noun_career", "adPhr_1"],
        ["vrb_bless", "pro_your", "noun_career", "adPhr_2"],
      ],
    },
  ],
  4: [{ S: [["vrb_better", "pro_your", "noun_studies"]] }],
  5: [{ S: [["vrb_better", "pro_your", "noun_studies"]] }],
  6: [
    { S: [["vrb_better", "pro_your", "noun_studies"]] },
    { May: [["vrb_better", "pro_your", "noun_studies"]] },
    { May: [["vrb_better", "pro_your", "noun_studies"]] },
    { You: [["vrb_better", "pro_your", "noun_studies"]] },
    {
      S: [
        [
          "vrb_bestow",
          "pro_with",
          "adj_great",
          "noun_success",
          "prep_inyour",
          "noun_studies",
        ],
      ],
    },
  ],
};
